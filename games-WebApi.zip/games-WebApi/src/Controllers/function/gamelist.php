<?php
//get all products
function getAllgamesproduct($db)
{
$sql = 'Select p.ID, p.Name, p.Genre, p.Price  from gamesproduct p ';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//get product by id
function getgamesproduct($db, $gamesproductId)
{
$sql = 'Select p.ID, p.Name, p.Genre, p.Price  from gamesproduct p  ';
$sql .= 'Where p.id = :id';
$stmt = $db->prepare ($sql);
$id = (int) $gamesproductId;
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//add new product
function creategamesproduct($db, $form_data) {
    $sql = 'Insert into gamesproduct (name, genre, price) ';
    $sql .= 'values (:name, :genre, :price )';
    $stmt = $db->prepare ($sql);
    $stmt->bindParam(':name', $form_data['name']);
    $stmt->bindParam(':genre', $form_data['genre']);
    $stmt->bindParam(':price', ($form_data['price']));
    $stmt->execute();
    return $db->lastInsertID();//insert last number.. continue
    }
    //delete product by id
function deletegamesproduct($db,$gamesproductId) {
    $sql = ' Delete from gamesproduct where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$gamesproductId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    }
    //update product by id
    function updategamesproduct($db,$form_data,$gamesproductId) {
    $sql = 'UPDATE gamesproduct SET name = :name , genre = :genre , price = :price';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$gamesproductId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $form_data['name']);
    $stmt->bindParam(':genre', $form_data['genre']);
    $stmt->bindParam(':price', ($form_data['price']));
    $stmt->execute();
    }