<?php
use Slim\Http\Request; //namespace
use Slim\Http\Response; //namespace

//include gamelist.php file
include __DIR__ . '/function/gamelist.php';
//read table games
$app->get('/gamesproduct', function (Request $request, Response $response, array
$arg){
return $this->response->withJson(array('data' => 'success'), 200);
});
// read all data from table games
$app->get('/allgamesproduct',function (Request $request, Response $response,
array $arg)
{
$data = getAllgamesproduct($this->db);
if (is_null($data)) {
return $this->response->withHeader('Access-Control-Allow-Origin', '*')->withJson(array('error' => 'no data'), 404);
}
return $this->response->withJson(array('data' => $data), 200);
});
//request table gamesproduct by condition (product id)
$app->get('/gamesproduct/[{id}]', function ($request, $response, $args){
$gamesproductId = $args['id'];
if (!is_numeric($gamesproductId)) {
return $this->response->withJson(array('error' => 'numeric paremeter required'), 500);
}
$data = getgamesproduct($this->db,$gamesproductId);
if (empty($data)) {
return $this->response->withJson(array('error' => 'no data'), 500);
}
return $this->response->withJson(array('data' => $data), 200);
});
//post method
$app->post('/gamesproduct/add', function ($request, $response, $args) {
    $form_data = $request->getParsedBody();
    $data = creategamesproduct($this->db, $form_data);
    if ($data <= 0) {
    return $this->response->withJson(array('error' => 'add data fail'), 500);
    }
    return $this->response->withJson(array('add data' => 'success'), 200);
    }
    );

//delete row
$app->delete('/gamesproduct/del/[{id}]', function ($request, $response, $args){
    $gamesproductId = $args['id'];
    if (!is_numeric($gamesproductId)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $data = deletegamesproduct($this->db,$gamesproductId);
    if (empty($data)) {
    return $this->response->withJson(array($gamesproductId=> 'is successfully deleted'), 202);};
    });
    
    //put table products
    $app->put('/gamesproduct/put/[{id}]', function ($request, $response, $args){
    $gamesproductId = $args['id'];
    if (!is_numeric($gamesproductId)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $form_data=$request->getParsedBody();
    $data=updategamesproduct($this->db,$form_data,$gamesproductId);
    if ($data <=0)
    return $this->response->withJson(array('data' => 'successfully updated'), 200);
});